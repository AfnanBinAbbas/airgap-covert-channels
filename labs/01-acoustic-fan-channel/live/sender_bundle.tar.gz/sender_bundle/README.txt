# Air-gap acoustic sender (lab, own machines only)
# python3 send_live.py --message "HELLO" --repeats 5
# sudo python3 send_live.py --keygrab
# Default tones 1000,2500 Hz @ 50 baud; --tones 400,800 for fan style
